package com.rollerslab.rollingpotato.user.dao;

import java.util.List;
import java.util.Map;

public interface MainDao {
	public List<Map<Integer,String>> getTest();
}
