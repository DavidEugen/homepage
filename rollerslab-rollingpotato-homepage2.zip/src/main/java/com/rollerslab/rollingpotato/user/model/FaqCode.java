package com.rollerslab.rollingpotato.user.model;

public class FaqCode {
	
	public String langCode = "";	//lang Code
	public String sheetCode = "";	//Sheet Code
	public String sheetName = "";
	
	public String getLangCode() {
		return langCode;
	}
	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}
	public String getSheetCode() {
		return sheetCode;
	}
	public void setSheetCode(String sheetCode) {
		this.sheetCode = sheetCode;
	}
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
	
}
