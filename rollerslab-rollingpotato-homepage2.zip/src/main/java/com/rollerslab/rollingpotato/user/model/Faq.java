package com.rollerslab.rollingpotato.user.model;

public class Faq {
	public String SheetCode = "";	//Sheet Code
	public String DataCode = "";
	public String enQ = "";
	public String enA = "";
	public String krQ = "";
	public String krA = "";
	public String question = "";
	public String answer = "";
	
	
	public String getSheetCode() {
		return SheetCode;
	}
	public void setSheetCode(String sheetCode) {
		SheetCode = sheetCode;
	}
	public String getDataCode() {
		return DataCode;
	}
	public void setDataCode(String dataCode) {
		DataCode = dataCode;
	}
	public String getEnQ() {
		return enQ;
	}
	public void setEnQ(String enQ) {
		this.enQ = enQ;
	}
	public String getEnA() {
		return enA;
	}
	public void setEnA(String enA) {
		this.enA = enA;
	}
	public String getKrQ() {
		return krQ;
	}
	public void setKrQ(String krQ) {
		this.krQ = krQ;
	}
	public String getKrA() {
		return krA;
	}
	public void setKrA(String krA) {
		this.krA = krA;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
